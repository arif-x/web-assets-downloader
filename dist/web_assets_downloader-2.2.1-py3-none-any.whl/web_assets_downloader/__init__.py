from .web_assets_downloader import download_html_and_asset

def downloader(urls, save_folder):
    download_html_and_asset(urls, save_folder)